from flask import Flask, request, jsonify, render_template
from datetime import datetime, timezone

app = Flask(__name__)
locations = {}

@app.get("/")
def home():
    return render_template("home.html")

@app.get("/share")
def share():
    return render_template("share.html")

@app.get("/view")
def view():
    return render_template("view.html")

@app.post("/api/location")
def save_location():
    data=request.get_json(silent=True) or {}
    room=str(data.get("room","")).strip()
    lat=data.get("latitude")
    lon=data.get("longitude")
    if not room or lat is None or lon is None:
        return jsonify(ok=False, message="Data tidak lengkap"), 400
    locations[room]={
        "lat":float(lat), "lon":float(lon),
        "time":datetime.now(timezone.utc).isoformat()
    }
    return jsonify(ok=True)

@app.get("/api/location/<room>")
def get_location(room):
    item=locations.get(room)
    if not item:
        return jsonify(ok=False)
    return jsonify(ok=True, location=item)

@app.delete("/api/location/<room>")
def delete_location(room):
    locations.pop(room, None)
    return jsonify(ok=True)

if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000)
